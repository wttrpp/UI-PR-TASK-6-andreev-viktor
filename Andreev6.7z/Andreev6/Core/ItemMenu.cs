﻿using MaterialDesignThemes.Wpf;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Controls;

namespace Andreev6.Core
{
    internal class ItemMenu
    {
        private string v;
        private List<SubItem> menuReg;
        private PackIconKind register;

        public string MenuHeader { get; private set; }

        public PackIconKind Icon { get; private set; }

        public List<SubItem> SubItems { get; private set; }

        public UserControl UControl { get; private set; }

        public ItemMenu(string menuHeader, PackIconKind icon, List<SubItem> subItems, UserControl uControl)
        {
            MenuHeader = menuHeader;
            Icon = icon;
            SubItems = subItems;
        }

        public ItemMenu(string v, List<SubItem> menuReg, PackIconKind register)
        {
            this.v = v;
            this.menuReg = menuReg;
            this.register = register;
        }
    }
}
